"""VPN service application."""

